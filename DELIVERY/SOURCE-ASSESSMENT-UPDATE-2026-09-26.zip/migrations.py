"""migrations.py — هجرة مخططة بإصدارات لقاعدة البيانات (التسليم 4).

القرارات المطبقة هنا (ADR-001 + إعادة تأطيره):
- sha256 هي البصمة القانونية المعتمدة؛ عمود md5 التاريخي (content_hash) يبقى
  للمطابقة مع القواعد القديمة ولا تُكتب عليه اعتمادات جديدة.
- كل هجرة إضافة فقط (additive) — لا حذف ولا تعديل أعمدة قائمة — حتى يكون
  التراجع آمناً: نسخة احتياطية قبل التطبيق + استعادتها تكفي.
"""
import hashlib
import shutil
from datetime import datetime
from pathlib import Path

from config import DB_PATH
from logging_setup import get_log

log = get_log(__name__)

BACKUP_DIR = Path("data/backups")


def _sha256_text(text: str) -> str:
    return hashlib.sha256((text or "").strip().encode("utf-8")).hexdigest()


def _migration_001_sha256(cursor) -> dict:
    """إضافة بصمات sha256 وربط اللقطات الخام.

    - content_sha256: بصمة النص النظيف (بديل content_hash/md5 going forward).
    - snapshot_sha256: بصمة HTML الخام المخزّن في data/snapshots (يملأه
      الزاحف للوثائق الجديدة؛ التاريخيات تُترك فارغة لأن HTML لم يُحفظ لها).
    """
    stats = {"backfilled": 0, "empty": 0}
    cursor.execute("ALTER TABLE documents ADD COLUMN content_sha256 TEXT")
    cursor.execute("ALTER TABLE documents ADD COLUMN snapshot_sha256 TEXT")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_docs_content_sha256 "
                   "ON documents(content_sha256)")
    rows = cursor.execute(
        "SELECT id, clean_content, raw_content FROM documents").fetchall()
    for row in rows:
        text = row[1] or row[2]
        if text:
            cursor.execute(
                "UPDATE documents SET content_sha256 = ? WHERE id = ?",
                (_sha256_text(text), row[0]))
            stats["backfilled"] += 1
        else:
            stats["empty"] += 1
    return stats


def _migration_002_chunks_fts(cursor) -> dict:
    """جدول chunks للفهرسة النصية + FTS5 بتقسيم unicode61 (يحترم العربية)."""
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS chunks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_id INTEGER, article_id INTEGER, seq INTEGER,
            number TEXT, label TEXT, hierarchy_path TEXT,
            text TEXT, char_count INTEGER,
            source_url TEXT, doc_title TEXT
        )''')
    cursor.execute("""
        CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5(
            text, content='chunks', content_rowid='id',
            tokenize='unicode61')""")
    n = cursor.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
    return {"chunks_existing": n}


def _migration_003_sources_decided_by(cursor) -> dict:
    """من قرّر اعتماد/رفض المصدر: 'user' أم الطيار الآلي 'auto'.

    إضافة فقط (قاعدة الهجرات) — القيم التاريخية تبقى NULL وتُقرأ «غير مسجل».
    قواعد أقدم من جدول sources تُبنى بالجداول كاملة (CREATE IF NOT EXISTS)
    ثم يُضاف العمود لمن يملك الجدول بدونه — idempotent في الحالتين.
    """
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS sources (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        source_key TEXT UNIQUE,
        base_url TEXT UNIQUE,
        name TEXT,
        engine TEXT,
        credibility REAL DEFAULT 0.6,
        status TEXT DEFAULT 'proposed',
        discovered_via TEXT,
        discovered_at TEXT,
        decided_at TEXT,
        decided_by TEXT
    )
    ''')
    cols = [r[1] for r in cursor.execute("PRAGMA table_info(sources)")]
    added = 0
    if "decided_by" not in cols:
        cursor.execute("ALTER TABLE sources ADD COLUMN decided_by TEXT")
        added = 1
    n = cursor.execute("SELECT COUNT(*) FROM sources").fetchone()[0]
    return {"sources_rows": n, "column_added": added}


def _add_column_if_missing(cursor, table, column, decl) -> int:
    """يضيف عموداً فقط إن لم يكن موجوداً — idempotent، بلا خطأ عند التكرار.

    قواعد تاريخية جداً (fixtures اختبار قديمة أو قواعد جزئية) قد لا تملك
    الجدول نفسه بعد (مثال: crawl_runs لم يكن موجوداً قبل التسليم 3) — في
    هذه الحالة لا شيء لإضافته، والتجاهل هنا آمن: create_tables تُنشئ
    الجدول لاحقاً بمخططه الكامل مباشرة عند أول استخدام فعلي."""
    tables = [r[0] for r in cursor.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
        (table,))]
    if not tables:
        return 0
    cols = [r[1] for r in cursor.execute(f"PRAGMA table_info({table})")]
    if column in cols:
        return 0
    cursor.execute(f"ALTER TABLE {table} ADD COLUMN {column} {decl}")
    return 1


def _migration_004_self_discovery(cursor) -> dict:
    """يضيف مخطط الاكتشاف الذاتي للمصادر (DELIVERY/DESIGN-SELF-DISCOVERY.md):

    - documents: identity_key/identity_confidence (هوية القانون نوع+رقم+
      سنة، §2)، is_complete_text (اكتمال النص، §4.2.2)، source_domain_tier
      (فئة رسمية المصدر منسوخة وقت الحفظ، §4.2.1)، quality_score (كانت
      تُحسب فعلياً بـ extract_main_content ولا تُحفظ أبداً — تُخزَّن الآن
      لاستخدامها كمعيار ثالث بالمقارنة عند تعادل الفئة والاكتمال).
    - sources.domain_tier: فئة الرسمية لكل مصدر (0=أعلى رسمية..4=منتدى عام).
    - document_versions: نسخ الوثائق المستبدلة — نسخ لا حذف (§4.2).
    - dedup_decisions: سجل تدقيق لكل قرار تنقيح بين نسختين (§4.2).
    - source_performance: تعلّم بسيط شفاف من أداء كل مصدر عبر الدورات (§5.2).

    كل ما هنا إضافي بحت (أعمدة/جداول جديدة) — لا حذف ولا تعديل لعمود قائم،
    التزاماً بقاعدة الهجرات الإضافية في CONSTITUTION.md.
    """
    added = 0
    added += _add_column_if_missing(cursor, "documents", "identity_key", "TEXT")
    added += _add_column_if_missing(cursor, "documents", "identity_confidence", "TEXT")
    added += _add_column_if_missing(cursor, "documents", "is_complete_text", "INTEGER")
    added += _add_column_if_missing(cursor, "documents", "source_domain_tier", "INTEGER")
    added += _add_column_if_missing(cursor, "documents", "quality_score", "REAL")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_docs_identity "
                   "ON documents(identity_key)")

    added += _add_column_if_missing(cursor, "sources", "domain_tier",
                                    "INTEGER DEFAULT 4")
    added += _add_column_if_missing(cursor, "crawl_runs",
                                    "branch_breakdown_json", "TEXT")

    cursor.execute('''
        CREATE TABLE IF NOT EXISTS document_versions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            original_doc_id INTEGER,
            doc_id TEXT, title TEXT, source_url TEXT,
            clean_content TEXT, quality_score REAL,
            superseded_at TEXT, superseded_reason TEXT,
            FOREIGN KEY (original_doc_id) REFERENCES documents(id)
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS dedup_decisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            identity_key TEXT,
            winner_doc_id INTEGER, loser_doc_id INTEGER,
            decisive_criterion TEXT,
            winner_value REAL, loser_value REAL,
            decided_at TEXT
        )
    ''')
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS source_performance (
            source_key TEXT PRIMARY KEY,
            runs_count INTEGER DEFAULT 0,
            new_identities_total INTEGER DEFAULT 0,
            last_run_new_identities INTEGER DEFAULT 0,
            consecutive_empty_runs INTEGER DEFAULT 0,
            last_evaluated_at TEXT,
            learned_status TEXT DEFAULT 'active'
        )
    ''')
    return {"columns_added": added}


def _migration_005_rejection_feedback(cursor) -> dict:
    """سبب رفض صريح عند المراجعة البشرية (طلب المالك 2026-09-06): «حتى
    يتعلّم الزاحف للمرات القادمة». سجل تدقيق كامل (من رفض ماذا ولماذا)
    + عمود تنازلي بسيط على sources يُقرأ عند البذر القادم (learning.py).

    - rejection_reasons: سجل كل رفض بشري (doc_id, source_key, الفئة، ملاحظة حرة).
    - sources.rejection_count: عدّاد تراكمي بسيط — يُستشار قبل البذر
      (نفس فكرة learned_status الحالية، بس مصدرها قرار بشري صريح لا
      عدّاد فارغ آلي). إضافي بحت، لا يمسّ learned_status الموجود أصلاً.
    """
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS rejection_reasons (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            doc_id INTEGER,
            source_key TEXT,
            category TEXT,
            note TEXT,
            rejected_at TEXT,
            FOREIGN KEY (doc_id) REFERENCES documents(id)
        )
    ''')
    added = _add_column_if_missing(cursor, "sources", "rejection_count",
                                   "INTEGER DEFAULT 0")
    return {"table_created": True, "columns_added": added}


def _migration_006_law_status(cursor) -> dict:
    """ف١ (EXPANSION-CHARTER §2): سلسلة التعديلات والحالة القانونية.

    - law_amendments: كل وثيقة تستهدف صكاً آخر بتعديل/إلغاء (المصدر:
      تصنيف سياق الإحالات المستخرجة نصياً — law_status.py).
    - documents.legal_status: ملغى/معدَّل/ساري — يحسبه law_status.
      compute_legal_statuses من السلسلة؛ القاعدة القائمة تُبنى بـ
      `python3 cli.py law-status --rebuild`.
    """
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS law_amendments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            amending_doc_id INTEGER NOT NULL,
            target_identity TEXT NOT NULL,
            action TEXT NOT NULL CHECK (action IN ('amend','repeal')),
            context TEXT,
            created_at TEXT,
            UNIQUE (amending_doc_id, target_identity, action),
            FOREIGN KEY (amending_doc_id) REFERENCES documents(id)
        )
    ''')
    added = _add_column_if_missing(cursor, "documents", "legal_status",
                                   "TEXT")
    return {"law_amendments": True, "documents.legal_status_added": added}


def _migration_007_doc_nature(cursor) -> dict:
    """ف٤: طبيعة الوثيقة (doc_nature.py) — قِيس على عيّنة المالك: 208 من
    262 «بلا هوية» أعمالٌ تحضيرية لا صكوك. nature تُحسم عند الحفظ، والقاعدة
    القائمة تُصنَّف بـ `cli nature --reclassify`. travaux_article = رقم
    المادة المشروحة (للأعمال التحضيرية فقط)."""
    a = _add_column_if_missing(cursor, "documents", "nature",
                               "TEXT DEFAULT 'instrument'")
    b = _add_column_if_missing(cursor, "documents", "travaux_article",
                               "INTEGER")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_documents_nature "
                   "ON documents(nature)")
    return {"columns_added": a + b}


def _migration_008_law_parts(cursor) -> dict:
    """ف٧: documents.part_of — الجزء يشير إلى وثيقة الرأس لصكٍّ دخل شذرات
    (law_parts.py). قِيس على قاعدة المالك: قانون الجمارك 38 والمرسوم
    التشريعي 30 وأصول المحاكمات 2016. لا حذف ولا دمج نصوص؛ علاقة فقط."""
    a = _add_column_if_missing(cursor, "documents", "part_of", "INTEGER")
    cursor.execute("CREATE INDEX IF NOT EXISTS idx_documents_part_of "
                   "ON documents(part_of)")
    return {"columns_added": a}


def _migration_009_parent_identity(cursor) -> dict:
    """ف٩: documents.parent_identity — الصك التابع (لائحة/تعليمات تنفيذية)
    يشير إلى مفتاح هوية قانونه الأم (regulations.py). علاقة فقط."""
    a = _add_column_if_missing(cursor, "documents", "parent_identity", "TEXT")
    return {"columns_added": a}


def _migration_010_issue_date(cursor) -> dict:
    """A-2: تاريخ الإصدار (issue_date.py) — ميلادي ISO، هجري نصاً، وثقة."""
    a = 0
    for col, decl in (("issue_date", "TEXT"), ("issue_date_hijri", "TEXT"),
                      ("issue_date_confidence", "TEXT")):
        a += _add_column_if_missing(cursor, "documents", col, decl)
    return {"columns_added": a}


def _migration_011_status_reason(cursor) -> dict:
    """A-3: documents.legal_status_reason — نص الدليل (من أي صك، بأي تاريخ)."""
    a = _add_column_if_missing(cursor, "documents", "legal_status_reason", "TEXT")
    return {"columns_added": a}


def _migration_012_precedents_v2(cursor) -> dict:
    """ف٣ (أ-2): الاجتهادات — خمسة جداول (docs/PRECEDENTS-RESEARCH-2026-09-21.md §9).

    decisions: هوية القرار (محكمة/دائرة/غرفة/أرقام) — سجل واحد لكل قرار حقيقي.
    principles: المبدأ المستخلص ← قرار (قد يتعدد).
    citations: كل ظهور منشور (المصدر + السطر حرفياً + الثقة).
    decision_relations: عدول/تأكيد/إحالة/تعارض.
    principle_articles: ربط المبدأ بمادة تشريع موجود في documents.
    جدول precedents القديم يبقى (إضافة فقط) ولا يُستعمل بعد الآن.
    """
    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS decisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        court TEXT NOT NULL,
        division TEXT,
        chamber_raw TEXT,
        case_kind TEXT,
        decision_number TEXT,
        decision_year INTEGER,
        basis_number TEXT,
        basis_year INTEGER,
        appeal_number TEXT,
        decision_date TEXT,
        identity_key TEXT UNIQUE,
        full_text TEXT,
        full_text_sha256 TEXT,
        authority_rank INTEGER,
        review_status TEXT DEFAULT 'pending',
        reviewed_by TEXT,
        reviewed_at TEXT,
        created_at TEXT
    );
    CREATE TABLE IF NOT EXISTS principles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        decision_id INTEGER NOT NULL REFERENCES decisions(id),
        title_keywords TEXT,
        text TEXT NOT NULL,
        text_sha256 TEXT UNIQUE,
        review_status TEXT DEFAULT 'pending',
        created_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_principles_decision ON principles(decision_id);
    CREATE TABLE IF NOT EXISTS citations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        decision_id INTEGER NOT NULL REFERENCES decisions(id),
        principle_id INTEGER REFERENCES principles(id),
        source_site TEXT,
        source_url TEXT,
        snapshot_ts TEXT,
        publication TEXT,
        pub_year INTEGER,
        pub_issue TEXT,
        pub_page TEXT,
        rule_number TEXT,
        citation_raw TEXT,
        parse_confidence REAL,
        scraped_at TEXT
    );
    CREATE INDEX IF NOT EXISTS idx_citations_decision ON citations(decision_id);
    CREATE UNIQUE INDEX IF NOT EXISTS uq_citations_url_raw ON citations(source_url, citation_raw);
    CREATE TABLE IF NOT EXISTS decision_relations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        from_decision_id INTEGER NOT NULL REFERENCES decisions(id),
        to_decision_id INTEGER NOT NULL REFERENCES decisions(id),
        relation TEXT NOT NULL,
        evidence_text TEXT,
        created_at TEXT,
        UNIQUE(from_decision_id, to_decision_id, relation)
    );
    CREATE TABLE IF NOT EXISTS principle_articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        principle_id INTEGER NOT NULL REFERENCES principles(id),
        document_id INTEGER,
        law_alias TEXT,
        article_number TEXT NOT NULL,
        article_numbering_scheme TEXT DEFAULT 'as_cited',
        match_method TEXT,
        confidence REAL,
        UNIQUE(principle_id, law_alias, article_number)
    );
    """)
    return {"tables": ["decisions", "principles", "citations",
                       "decision_relations", "principle_articles"]}


def _migration_013_source_assessment(cursor) -> dict:
    """حفظ التقييم الآلي للمصادر المكتشفة (طلب المالك 2026-09-26).

    الدرجة والأسباب/الأدلة منفصلة عن status: التوصية الآلية لا تعتمد المصدر
    ولا ترفضه في وضع «المقترحات فقط». كل التغييرات إضافية ومتوافقة مع القاعدة.
    """
    added = 0
    for column, decl in (
        ("evaluation_score", "REAL"),
        ("evaluation_verdict", "TEXT"),
        ("source_type", "TEXT"),
        ("evaluation_reasons_json", "TEXT"),
        ("evaluation_details_json", "TEXT"),
        ("evaluated_at", "TEXT"),
        ("evaluation_sample_count", "INTEGER DEFAULT 0"),
    ):
        added += _add_column_if_missing(cursor, "sources", column, decl)
    return {"columns_added": added}


MIGRATIONS = [
    (1, "sha256 fingerprints + snapshot link", _migration_001_sha256),
    (2, "chunks + FTS5 arabic text index", _migration_002_chunks_fts),
    (3, "sources.decided_by (user vs autopilot)", _migration_003_sources_decided_by),
    (4, "self-discovery: identity_key + domain_tier + versions/dedup/perf",
     _migration_004_self_discovery),
    (5, "rejection_reasons + sources.rejection_count (learn from human review)",
     _migration_005_rejection_feedback),
    (6, "law_amendments + documents.legal_status (ف١ amendment chain)",
     _migration_006_law_status),
    (7, "documents.nature + travaux_article (ف٤ doc_nature)",
     _migration_007_doc_nature),
    (8, "documents.part_of (ف٧ law_parts: أجزاء الصك الواحد)",
     _migration_008_law_parts),
    (9, "documents.parent_identity (ف٩ regulations: الصك التابع → الأم)",
     _migration_009_parent_identity),
    (10, "documents.issue_date/_hijri/_confidence (A-2 issue_date)",
     _migration_010_issue_date),
    (11, "documents.legal_status_reason (A-3)", _migration_011_status_reason),
    (12, "precedents v2: decisions/principles/citations/relations/articles (ف٣)",
     _migration_012_precedents_v2),
    (13, "sources.evaluation: score/type/verdict/evidence", _migration_013_source_assessment),
]
LATEST = MIGRATIONS[-1][0]


def get_version(conn) -> int:
    return conn.execute("PRAGMA user_version").fetchone()[0]


def backup_db(db_path=DB_PATH) -> Path | None:
    p = Path(db_path)
    if not p.exists():
        return None
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)
    dest = BACKUP_DIR / (p.stem + "_pre_mig_"
                         + datetime.now().strftime("%Y%m%d_%H%M%S") + ".db")
    shutil.copy2(p, dest)
    return dest


def migrate(db_path=DB_PATH) -> dict:
    """يطبق كل الهجرات غير المطبقة. Idempotent وآمنة للتكرار."""
    import sqlite3
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    report = {"start_version": get_version(conn), "applied": [], "backups": []}
    current = report["start_version"]
    pending = [(v, name, fn) for v, name, fn in MIGRATIONS if v > current]
    if not pending:
        report["end_version"] = current
        conn.close()
        return report
    backup = backup_db(db_path)
    if backup:
        report["backups"].append(str(backup))
    cursor = conn.cursor()
    try:
        for version, name, fn in pending:
            stats = fn(cursor)
            cursor.execute(f"PRAGMA user_version = {version}")
            conn.commit()
            report["applied"].append(
                {"version": version, "name": name, **stats})
            log.info(f"هجرة {version} مطبقة: {name} — {stats}")
    except Exception:
        conn.rollback()
        conn.close()
        raise
    report["end_version"] = get_version(conn)
    conn.close()
    return report
